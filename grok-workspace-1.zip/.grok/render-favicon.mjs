import { chromium } from "playwright";
import { readFileSync, writeFileSync } from "node:fs";

const svg = readFileSync("/workspace/.grok/favicon.svg.tmp", "utf8");
const html = `<!DOCTYPE html><html><head><style>
html,body{margin:0;width:32px;height:32px;background:transparent}
svg{display:block;width:32px;height:32px}
</style></head><body>${svg}</body></html>`;
writeFileSync("/workspace/.grok/favicon-32.html", html);

const browser = await chromium.launch();
const page = await browser.newPage({
  viewport: { width: 32, height: 32 },
  deviceScaleFactor: 1,
});
await page.goto("file:///workspace/.grok/favicon-32.html");
await page.screenshot({
  path: "/workspace/.grok/favicon-32.png",
  omitBackground: true,
});
await page.setViewportSize({ width: 16, height: 16 });
await page.screenshot({
  path: "/workspace/.grok/favicon-16.png",
  omitBackground: true,
});
await browser.close();
console.log("wrote favicon rasters");
