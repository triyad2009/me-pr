import { useState } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { Logo } from "@/components/logo";
import { useWallet } from "@/lib/store";
import { cn } from "@/lib/utils";

const nav = [
  { href: "/#trade", label: "Trade" },
  { href: "/#product", label: "Product" },
  { href: "/#about", label: "About" },
  { href: "/#community", label: "Community" },
  { href: "/#contact", label: "Contact" },
];

export function SiteHeader({ compact = false }: { compact?: boolean }) {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const user = useWallet((s) => s.user);
  const enterGuest = useWallet((s) => s.enterGuest);

  function startNow() {
    if (!user) enterGuest();
    void navigate({ to: "/app" });
  }

  return (
    <header className="relative z-30 flex items-center justify-between gap-3 px-4 py-4 sm:px-6 md:px-8 md:py-5">
      <Logo />

      <nav
        className="hidden items-center rounded-pill bg-card/70 px-2 py-1 shadow-sm ring-1 ring-white/80 lg:flex"
        aria-label="Primary"
      >
        {nav.map((item) => (
          <a
            key={item.href}
            href={item.href}
            className="rounded-pill px-3.5 py-2 text-sm text-muted transition-colors duration-150 hover:text-ink"
          >
            {item.label}
          </a>
        ))}
      </nav>

      <div className="flex items-center gap-2">
        {user && pathname === "/app" ? (
          <Link
            to="/app"
            className="hidden h-10 items-center rounded-pill bg-card px-4 text-sm font-medium text-ink shadow-sm ring-1 ring-white sm:inline-flex"
          >
            {user.name}
          </Link>
        ) : (
          <Link
            to="/login"
            className="hidden h-10 items-center rounded-pill bg-card px-5 text-sm font-medium text-ink shadow-sm ring-1 ring-white/80 sm:inline-flex"
          >
            Login
          </Link>
        )}
        <button
          type="button"
          onClick={startNow}
          className={cn(
            "inline-flex h-10 items-center rounded-pill bg-accent px-5 text-sm font-semibold text-card shadow-sm transition-transform duration-150 ease-out active:scale-96",
            compact && "px-4",
          )}
        >
          Start now
        </button>
        <button
          type="button"
          className="grid size-10 place-items-center rounded-full bg-card text-ink shadow-sm lg:hidden"
          aria-expanded={open}
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="size-4" /> : <Menu className="size-4" />}
        </button>
      </div>

      {open ? (
        <div className="absolute top-full right-4 left-4 z-40 rounded-card bg-card p-4 shadow-card sm:right-6 sm:left-6 lg:hidden">
          <nav className="flex flex-col" aria-label="Mobile">
            {nav.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="rounded-panel px-3 py-3 text-sm font-medium text-ink"
              >
                {item.label}
              </a>
            ))}
            <Link
              to="/login"
              onClick={() => setOpen(false)}
              className="rounded-panel px-3 py-3 text-sm font-medium text-ink"
            >
              Login
            </Link>
          </nav>
        </div>
      ) : null}
    </header>
  );
}
