import { useEffect, useId, useState, type FormEvent, type ReactNode } from "react";
import { Plus, X } from "lucide-react";
import { toast } from "sonner";
import { TokenIcon } from "@/components/crypto";
import { useWallet, type Asset } from "@/lib/store";
import { cn } from "@/lib/utils";

export function Overlay({
  open,
  onClose,
  children,
  labelledBy,
}: {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  labelledBy: string;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center p-3 sm:items-center">
      <button
        type="button"
        className="absolute inset-0 bg-ink/30"
        aria-label="Close dialog"
        onClick={onClose}
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby={labelledBy}
        className="relative w-full max-w-md rounded-card bg-card p-6 shadow-frame"
      >
        {children}
      </div>
    </div>
  );
}

const assets: Asset[] = ["BTC", "ETH", "USDT", "SOL"];

export function SendDialog({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const titleId = useId();
  const send = useWallet((s) => s.send);
  const [to, setTo] = useState("");
  const [amount, setAmount] = useState("120");
  const [asset, setAsset] = useState<Asset>("USDT");

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const value = Number(amount);
    const ok = send(value, to.trim() || "0x8f21…aa4c", asset);
    if (!ok) {
      toast.error("Not enough balance for that send.");
      return;
    }
    toast.success(`Sent ${value} ${asset}`);
    onClose();
  }

  return (
    <Overlay open={open} onClose={onClose} labelledBy={titleId}>
      <div className="mb-5 flex items-start justify-between gap-4">
        <div>
          <p className="text-sm font-medium text-muted">Quick send</p>
          <h2 id={titleId} className="font-display text-3xl text-ink">
            Send assets
          </h2>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="grid size-10 place-items-center rounded-full bg-page text-ink"
          aria-label="Close"
        >
          <X className="size-4" />
        </button>
      </div>
      <form className="flex flex-col gap-4" onSubmit={onSubmit}>
        <label className="flex flex-col gap-2 text-sm font-medium text-muted">
          Recipient
          <input
            value={to}
            onChange={(e) => setTo(e.target.value)}
            placeholder="0x24534… or @handle"
            className="h-12 rounded-panel border border-line bg-page px-4 text-ink outline-none focus:border-accent"
          />
        </label>
        <label className="flex flex-col gap-2 text-sm font-medium text-muted">
          Amount
          <input
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            inputMode="decimal"
            className="h-12 rounded-panel border border-line bg-page px-4 text-ink outline-none focus:border-accent"
          />
        </label>
        <div className="flex gap-2">
          {assets.map((a) => (
            <button
              key={a}
              type="button"
              onClick={() => setAsset(a)}
              className={cn(
                "flex flex-1 items-center justify-center gap-2 rounded-pill border py-2 text-xs font-semibold",
                asset === a
                  ? "border-accent bg-accent/10 text-ink"
                  : "border-line bg-page text-muted",
              )}
            >
              <TokenIcon asset={a} className="size-6" />
              {a}
            </button>
          ))}
        </div>
        <button
          type="submit"
          className="mt-2 inline-flex h-12 items-center justify-center gap-2 rounded-pill bg-cta font-semibold text-card shadow-cta"
        >
          <Plus className="size-4" strokeWidth={2.5} />
          Send now
        </button>
      </form>
    </Overlay>
  );
}

export function SwapDialog({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const titleId = useId();
  const swap = useWallet((s) => s.swap);
  const [from, setFrom] = useState<Asset>("BTC");
  const [to, setTo] = useState<Asset>("USDT");
  const [amount, setAmount] = useState("0.02");

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (from === to) {
      toast.error("Pick two different assets.");
      return;
    }
    const value = Number(amount);
    const ok = swap(value, from, to);
    if (!ok) {
      toast.error("Could not complete swap.");
      return;
    }
    toast.success(`Swapped ${value} ${from} to ${to}`);
    onClose();
  }

  return (
    <Overlay open={open} onClose={onClose} labelledBy={titleId}>
      <div className="mb-5 flex items-start justify-between gap-4">
        <div>
          <p className="text-sm font-medium text-muted">Quick swap</p>
          <h2 id={titleId} className="font-display text-3xl text-ink">
            Swap pairs
          </h2>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="grid size-10 place-items-center rounded-full bg-page text-ink"
          aria-label="Close"
        >
          <X className="size-4" />
        </button>
      </div>
      <form className="flex flex-col gap-4" onSubmit={onSubmit}>
        <label className="flex flex-col gap-2 text-sm font-medium text-muted">
          You pay
          <input
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            inputMode="decimal"
            className="h-12 rounded-panel border border-line bg-page px-4 text-ink outline-none focus:border-accent"
          />
        </label>
        <div className="grid grid-cols-2 gap-3">
          <label className="flex flex-col gap-2 text-sm font-medium text-muted">
            From
            <select
              value={from}
              onChange={(e) => setFrom(e.target.value as Asset)}
              className="h-12 rounded-panel border border-line bg-page px-3 text-ink outline-none"
            >
              {assets.map((a) => (
                <option key={a}>{a}</option>
              ))}
            </select>
          </label>
          <label className="flex flex-col gap-2 text-sm font-medium text-muted">
            To
            <select
              value={to}
              onChange={(e) => setTo(e.target.value as Asset)}
              className="h-12 rounded-panel border border-line bg-page px-3 text-ink outline-none"
            >
              {assets.map((a) => (
                <option key={a}>{a}</option>
              ))}
            </select>
          </label>
        </div>
        <p className="text-sm text-muted">100+ pairs for fast swap.</p>
        <button
          type="submit"
          className="mt-1 inline-flex h-12 items-center justify-center rounded-pill bg-cta font-semibold text-card shadow-cta"
        >
          Swap now
        </button>
      </form>
    </Overlay>
  );
}
