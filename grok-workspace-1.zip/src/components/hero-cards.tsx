import { useState } from "react";
import { BarChart3, Check, Copy, Plus, Send, Wallet } from "lucide-react";
import { TokenRow } from "@/components/crypto";
import { SendDialog, SwapDialog } from "@/components/dialogs";
import { useWallet } from "@/lib/store";
import { cn } from "@/lib/utils";

function formatUsd(n: number) {
  return n.toLocaleString("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
  });
}

const monthCopy: Record<string, string> = {
  jan: "January 2023",
  feb: "February 2023",
  mar: "April 2023",
  apr: "April 2023",
};

export function HeroCards() {
  const [sendOpen, setSendOpen] = useState(false);
  const [swapOpen, setSwapOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activeMonth, setActiveMonth] = useState<"jan" | "feb" | "mar" | "apr">(
    "mar",
  );
  const balance = useWallet((s) => s.balance);
  const dayChange = useWallet((s) => s.dayChange);
  const dayChangePct = useWallet((s) => s.dayChangePct);
  const address = useWallet((s) => s.address);
  const spend = useWallet((s) => s.spend);
  const maxSpend = Math.max(...spend.map((m) => m.value));

  function copyAddress() {
    void navigator.clipboard?.writeText("0x24534a91c0b23");
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1400);
  }

  return (
    <>
      <div className="relative mx-auto mt-8 w-full max-w-4xl lg:mt-4 lg:h-[430px]">
        <article
          className={cn(
            "glass-card flex min-h-40 flex-col justify-between rounded-card p-5",
            "transition-transform duration-250 ease-out",
            "lg:absolute lg:top-6 lg:left-0 lg:w-72 lg:-rotate-6",
            "lg:hover:z-30 lg:hover:rotate-0",
          )}
        >
          <div className="flex items-start justify-between">
            <h3 className="text-sm font-medium text-muted">Quick send</h3>
            <Send className="size-4 text-accent" aria-hidden="true" />
          </div>
          <div className="mt-10 flex items-center gap-3">
            <button
              type="button"
              onClick={() => setSendOpen(true)}
              className="grid size-11 place-items-center rounded-full bg-accent text-card shadow-cta transition-transform duration-150 ease-out active:scale-96"
              aria-label="Send assets"
            >
              <Plus className="size-5" strokeWidth={2.5} />
            </button>
            <TokenRow assets={["BTC", "ETH", "USDT", "SOL"]} />
          </div>
        </article>

        <article
          className={cn(
            "glass-card mt-4 flex min-h-28 items-center justify-between gap-4 rounded-card p-5",
            "transition-transform duration-250 ease-out",
            "lg:absolute lg:bottom-6 lg:left-8 lg:mt-0 lg:w-72 lg:-rotate-3",
            "lg:hover:z-30 lg:hover:rotate-0",
          )}
        >
          <div>
            <h3 className="text-sm font-medium text-muted">Quick swap</h3>
            <button
              type="button"
              onClick={() => setSwapOpen(true)}
              className="mt-4 text-left"
              aria-label="Open swap"
            >
              <TokenRow assets={["BTC", "ETH"]} />
            </button>
          </div>
          <p className="max-w-28 text-sm leading-snug text-muted">
            100+ pairs for fast swap
          </p>
        </article>

        <article
          className={cn(
            "glass-card relative z-20 mt-4 flex min-h-56 flex-col rounded-card p-6",
            "transition-transform duration-250 ease-out lg:hover:-translate-y-1",
            "lg:absolute lg:top-20 lg:left-1/2 lg:mt-0 lg:w-80 lg:-translate-x-1/2",
          )}
        >
          <div className="flex items-start justify-between">
            <h3 className="text-sm font-medium text-muted">Easy assets wallet</h3>
            <Wallet className="size-4 text-accent" aria-hidden="true" />
          </div>
          <div className="mt-5 flex items-center justify-between gap-3 text-sm text-muted">
            <span>Wallet 1</span>
            <span className="flex items-center gap-2">
              <button
                type="button"
                onClick={copyAddress}
                className="grid size-7 place-items-center rounded-full bg-page"
                aria-label="Copy wallet address"
              >
                <span className="relative grid size-4 place-items-center">
                  <Copy
                    className={cn(
                      "size-3.5 transition-[opacity,filter,transform] duration-250 ease-out",
                      copied
                        ? "scale-25 opacity-0 blur-xs"
                        : "scale-100 opacity-100 blur-none",
                    )}
                  />
                  <Check
                    className={cn(
                      "absolute size-3.5 text-accent transition-[opacity,filter,transform] duration-250 ease-out",
                      copied
                        ? "scale-100 opacity-100 blur-none"
                        : "scale-25 opacity-0 blur-xs",
                    )}
                  />
                </span>
              </button>
              <span className="font-mono text-xs">{address}</span>
            </span>
          </div>
          <p className="mt-6 text-4xl font-semibold tracking-tight text-ink tabular-nums md:text-5xl">
            {formatUsd(balance)}
          </p>
          <div className="mt-3 flex items-end justify-between text-sm">
            <span className="text-muted tabular-nums">{formatUsd(dayChange)}</span>
            <span className="font-semibold text-accent-2 tabular-nums">
              +{dayChangePct.toFixed(0)}%
            </span>
          </div>
        </article>

        <article
          className={cn(
            "glass-card mt-4 flex min-h-64 flex-col rounded-card p-5",
            "transition-transform duration-250 ease-out",
            "lg:absolute lg:top-4 lg:right-0 lg:mt-0 lg:w-80 lg:rotate-6",
            "lg:hover:z-30 lg:hover:rotate-0",
          )}
        >
          <div className="flex items-start justify-between">
            <h3 className="text-sm font-medium text-muted">You spend</h3>
            <BarChart3 className="size-4 text-accent" aria-hidden="true" />
          </div>
          <div className="mt-2 flex-1">
            <div className="grid min-h-16 grid-cols-4 items-end">
              {spend.map((month) => (
                <div key={month.key} className="flex justify-center">
                  {month.key === activeMonth ? (
                    <span className="rounded-xl bg-card px-2.5 py-1 text-left shadow-card">
                      <span className="block text-sm font-semibold text-ink tabular-nums">
                        {formatUsd(month.value)}
                      </span>
                      <span className="block text-xs tracking-wide text-faint uppercase">
                        {monthCopy[month.key]}
                      </span>
                    </span>
                  ) : null}
                </div>
              ))}
            </div>
            <div className="mt-2 flex h-28 items-end gap-3 px-2">
              {spend.map((month) => {
                const active = month.key === activeMonth;
                const height = Math.max(28, (month.value / maxSpend) * 104);
                return (
                  <button
                    key={month.key}
                    type="button"
                    onClick={() => setActiveMonth(month.key)}
                    className="flex flex-1 flex-col items-center gap-2"
                  >
                    <span
                      className={cn(
                        "w-10 rounded-2xl transition-colors duration-250",
                        active ? "bg-accent shadow-cta" : "bg-line",
                      )}
                      style={{ height }}
                    />
                  </button>
                );
              })}
            </div>
            <div className="mt-2 grid grid-cols-4">
              {spend.map((month) => (
                <span
                  key={month.key}
                  className="text-center text-xs text-muted"
                >
                  {month.label}
                </span>
              ))}
            </div>
          </div>
        </article>
      </div>

      <SendDialog open={sendOpen} onClose={() => setSendOpen(false)} />
      <SwapDialog open={swapOpen} onClose={() => setSwapOpen(false)} />
    </>
  );
}
