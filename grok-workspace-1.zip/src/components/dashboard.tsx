import { useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import {
  ArrowLeftRight,
  ArrowUpRight,
  LogOut,
  Plus,
} from "lucide-react";
import { HeroCards } from "@/components/hero-cards";
import { Logo } from "@/components/logo";
import { SiteFrame } from "@/components/site-frame";
import { markets, useWallet, type Transaction } from "@/lib/store";
import { cn } from "@/lib/utils";

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 18) return "Good afternoon";
  return "Good evening";
}

function timeAgo(at: number) {
  const mins = Math.max(1, Math.round((Date.now() - at) / 60000));
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 48) return `${hours}h ago`;
  return `${Math.round(hours / 24)}d ago`;
}

function txLabel(tx: Transaction) {
  if (tx.type === "send") return `Sent ${tx.asset}`;
  if (tx.type === "swap") return `Swapped ${tx.asset}`;
  return `Received ${tx.asset}`;
}

export function Dashboard() {
  const navigate = useNavigate();
  const user = useWallet((s) => s.user);
  const balance = useWallet((s) => s.balance);
  const txs = useWallet((s) => s.txs);
  const logout = useWallet((s) => s.logout);
  const [tab, setTab] = useState<"activity" | "markets">("activity");

  const firstName = useMemo(
    () => user?.name.split(" ")[0] ?? "there",
    [user],
  );

  function signOut() {
    logout();
    void navigate({ to: "/" });
  }

  return (
    <SiteFrame>
      <header className="flex items-center justify-between gap-3 px-4 py-4 sm:px-6 md:px-8 md:py-5">
        <Logo />
        <div className="flex items-center gap-2">
          <span className="hidden h-10 items-center rounded-pill bg-card px-4 text-sm font-medium text-ink shadow-sm ring-1 ring-white sm:inline-flex">
            {user?.email}
          </span>
          <button
            type="button"
            onClick={signOut}
            className="inline-flex h-10 items-center gap-2 rounded-pill bg-card px-4 text-sm font-medium text-ink shadow-sm ring-1 ring-white"
          >
            <LogOut className="size-4" />
            Log out
          </button>
        </div>
      </header>

      <main className="px-4 pb-16 sm:px-6 md:px-8">
        <div className="mx-auto max-w-5xl">
          <p className="text-sm font-medium text-accent-2">
            {greeting()}, {firstName}
          </p>
          <h1 className="mt-2 font-display text-4xl text-ink md:text-5xl">
            Your NextO wallet
          </h1>
          <p className="mt-3 max-w-xl text-muted">
            {balance.toLocaleString("en-US", {
              style: "currency",
              currency: "USD",
            })}{" "}
            ready to send, swap, or simply watch.
          </p>

          <div className="mt-6 flex flex-wrap gap-2">
            <a
              href="#workspace"
              className="inline-flex h-11 items-center gap-2 rounded-pill bg-cta px-5 text-sm font-semibold text-card shadow-cta"
            >
              <Plus className="size-4" strokeWidth={2.5} />
              Send
            </a>
            <a
              href="#workspace"
              className="inline-flex h-11 items-center gap-2 rounded-pill bg-card px-5 text-sm font-semibold text-ink shadow-sm ring-1 ring-white"
            >
              <ArrowLeftRight className="size-4" />
              Swap
            </a>
            <a
              href="#markets"
              className="inline-flex h-11 items-center gap-2 rounded-pill bg-card px-5 text-sm font-semibold text-ink shadow-sm ring-1 ring-white"
            >
              <ArrowUpRight className="size-4" />
              Markets
            </a>
          </div>
        </div>

        <div id="workspace" className="scroll-mt-8">
          <HeroCards />
        </div>

        <section
          id="markets"
          className="mx-auto mt-12 max-w-5xl scroll-mt-8 rounded-card bg-card/80 p-5 shadow-card ring-1 ring-white md:p-6"
        >
          <div className="flex gap-2">
            {(["activity", "markets"] as const).map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => setTab(item)}
                className={cn(
                  "h-10 rounded-pill px-4 text-sm font-medium capitalize",
                  tab === item
                    ? "bg-ink text-card"
                    : "bg-page text-muted",
                )}
              >
                {item}
              </button>
            ))}
          </div>

          {tab === "activity" ? (
            <ul className="mt-5 divide-y divide-line">
              {txs.slice(0, 8).map((tx) => (
                <li
                  key={tx.id}
                  className="flex items-center justify-between gap-3 py-4"
                >
                  <div>
                    <p className="font-medium text-ink">{txLabel(tx)}</p>
                    <p className="text-sm text-muted">{tx.counterparty}</p>
                  </div>
                  <div className="text-right">
                    <p
                      className={cn(
                        "font-medium tabular-nums",
                        tx.type === "receive" ? "text-accent-2" : "text-ink",
                      )}
                    >
                      {tx.type === "receive" ? "+" : "-"}
                      {tx.amount} {tx.asset}
                    </p>
                    <p className="text-xs text-faint">{timeAgo(tx.at)}</p>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <div className="mt-5">
              {markets.map((row) => (
                <div
                  key={row.pair}
                  className="flex items-center justify-between border-b border-line py-3 last:border-0"
                >
                  <span className="font-medium text-ink">{row.pair}</span>
                  <span className="text-ink tabular-nums">${row.price}</span>
                  <span
                    className={cn(
                      "font-medium tabular-nums",
                      row.change >= 0 ? "text-accent-2" : "text-down",
                    )}
                  >
                    {row.change >= 0 ? "+" : ""}
                    {row.change.toFixed(2)}%
                  </span>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>
    </SiteFrame>
  );
}
