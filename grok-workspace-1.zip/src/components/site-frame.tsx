import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function SiteFrame({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className="min-h-dvh bg-canvas p-2 sm:p-3 md:p-5">
      <div
        className={cn(
          "page-shell relative mx-auto min-h-[calc(100dvh-1rem)] overflow-hidden rounded-3xl md:min-h-[calc(100dvh-2.5rem)] md:rounded-frame",
          className,
        )}
      >
        {children}
      </div>
    </div>
  );
}
