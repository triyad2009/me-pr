import { useState, type FormEvent } from "react";
import { useNavigate } from "@tanstack/react-router";
import {
  ArrowLeftRight,
  ArrowUpRight,
  Globe,
  ShieldCheck,
  Users,
  Wallet,
  Zap,
} from "lucide-react";
import { toast } from "sonner";
import { Logo } from "@/components/logo";
import { markets, useWallet } from "@/lib/store";
import { cn } from "@/lib/utils";

export function PageSections() {
  const navigate = useNavigate();
  const enterGuest = useWallet((s) => s.enterGuest);
  const user = useWallet((s) => s.user);

  function enter() {
    if (!user) enterGuest();
    void navigate({ to: "/app" });
  }

  return (
    <>
      <section id="trade" className="scroll-mt-24 px-5 py-20 md:px-10 lg:px-14">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-sm font-medium text-accent-2">Trade</p>
            <h2 className="mt-2 font-display text-4xl text-ink md:text-5xl">
              Markets that stay out of the way
            </h2>
          </div>
          <button
            type="button"
            onClick={enter}
            className="inline-flex h-11 items-center gap-2 rounded-pill bg-card px-5 text-sm font-semibold text-ink shadow-sm ring-1 ring-white"
          >
            Open terminal
            <ArrowUpRight className="size-4" />
          </button>
        </div>
        <div className="overflow-hidden rounded-card bg-card/80 shadow-card ring-1 ring-white">
          <div className="grid grid-cols-12 border-b border-line px-5 py-3 text-xs tracking-wide text-faint uppercase">
            <span className="col-span-4">Pair</span>
            <span className="col-span-3 text-right">Price</span>
            <span className="col-span-2 text-right">24h</span>
            <span className="col-span-3 text-right">Volume</span>
          </div>
          {markets.map((row) => (
            <div
              key={row.pair}
              className="grid grid-cols-12 items-center border-b border-line/70 px-5 py-4 last:border-0"
            >
              <span className="col-span-4 font-medium text-ink">{row.pair}</span>
              <span className="col-span-3 text-right tabular-nums text-ink">
                ${row.price}
              </span>
              <span
                className={cn(
                  "col-span-2 text-right font-medium tabular-nums",
                  row.change >= 0 ? "text-accent-2" : "text-down",
                )}
              >
                {row.change >= 0 ? "+" : ""}
                {row.change.toFixed(2)}%
              </span>
              <span className="col-span-3 text-right text-muted tabular-nums">
                {row.volume}
              </span>
            </div>
          ))}
        </div>
      </section>

      <section id="product" className="scroll-mt-24 px-5 py-12 md:px-10 lg:px-14">
        <p className="text-sm font-medium text-accent-2">Product</p>
        <h2 className="mt-2 max-w-xl font-display text-4xl text-ink md:text-5xl">
          Four moves. The whole crypto stack.
        </h2>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            {
              icon: Zap,
              title: "Quick send",
              body: "Push any asset to a handle or address in two taps, with a live fee preview.",
            },
            {
              icon: ArrowLeftRight,
              title: "Fast swap",
              body: "Route across 100+ pairs without leaving the wallet. Quotes refresh as you type.",
            },
            {
              icon: Wallet,
              title: "Assets wallet",
              body: "One balance, many chains. Copy your address, track the day, stay in control.",
            },
            {
              icon: ShieldCheck,
              title: "Spend insight",
              body: "See where value actually went — month by month — instead of a raw ledger.",
            },
          ].map((item) => (
            <article
              key={item.title}
              className="rounded-card bg-card/80 p-6 shadow-card ring-1 ring-white"
            >
              <item.icon className="size-5 text-accent-2" />
              <h3 className="mt-5 text-lg font-semibold text-ink">{item.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted">{item.body}</p>
            </article>
          ))}
        </div>
      </section>

      <section
        id="about"
        className="scroll-mt-24 px-5 py-16 md:px-10 lg:grid lg:grid-cols-12 lg:gap-10 lg:px-14"
      >
        <div className="lg:col-span-6">
          <p className="text-sm font-medium text-accent-2">About</p>
          <h2 className="mt-2 font-display text-4xl text-ink md:text-5xl">
            Built for how finance actually feels now
          </h2>
          <p className="mt-5 max-w-lg text-base leading-relaxed text-muted">
            NextO is a platform for people who want blockchain, DeFi, and the
            broader crypto ecosystem without the noise. We started with send,
            swap, and a clear wallet — then added spend tracking so the numbers
            mean something.
          </p>
        </div>
        <dl className="mt-10 grid grid-cols-3 gap-4 lg:col-span-6 lg:mt-10">
          {[
            ["2.4M", "Wallets opened"],
            ["100+", "Swap pairs"],
            ["0.04s", "Quote time"],
          ].map(([stat, label]) => (
            <div
              key={label}
              className="rounded-card bg-card/80 p-5 text-center shadow-card ring-1 ring-white"
            >
              <dt className="font-display text-3xl text-ink md:text-4xl">{stat}</dt>
              <dd className="mt-2 text-xs text-muted md:text-sm">{label}</dd>
            </div>
          ))}
        </dl>
      </section>

      <section
        id="community"
        className="scroll-mt-24 px-5 py-12 md:px-10 lg:px-14"
      >
        <div className="rounded-card bg-card/80 px-6 py-10 shadow-card ring-1 ring-white md:px-10">
          <div className="flex flex-col justify-between gap-8 md:flex-row md:items-center">
            <div>
              <p className="inline-flex items-center gap-2 text-sm font-medium text-accent-2">
                <Users className="size-4" />
                Community
              </p>
              <h2 className="mt-3 max-w-md font-display text-4xl text-ink">
                Builders, traders, and the quietly curious
              </h2>
              <p className="mt-4 max-w-md text-muted">
                Weekly market notes, office hours, and a forum that still reads
                like people — not bots.
              </p>
            </div>
            <div className="flex flex-col gap-3">
              <a
                href="#contact"
                className="inline-flex h-12 items-center justify-center gap-2 rounded-pill bg-cta px-6 font-semibold text-card shadow-cta"
              >
                <Globe className="size-4" />
                Join the room
              </a>
              <p className="text-center text-sm text-muted">
                86k members across 40 countries
              </p>
            </div>
          </div>
        </div>
      </section>

      <ContactSection />

      <footer className="mt-8 flex flex-col gap-6 border-t border-white/60 px-5 py-8 md:flex-row md:items-center md:justify-between md:px-10 lg:px-14">
        <Logo />
        <p className="text-sm text-muted">
          © {new Date().getFullYear()} NextO. Digital finance, without the fog.
        </p>
      </footer>
    </>
  );
}

function ContactSection() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState(false);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) {
      toast.error("Please fill in every field.");
      return;
    }
    setSent(true);
    toast.success("Message received. We’ll write back shortly.");
    setName("");
    setEmail("");
    setMessage("");
  }

  return (
    <section id="contact" className="scroll-mt-24 px-5 py-16 md:px-10 lg:px-14">
      <div className="grid gap-10 lg:grid-cols-2">
        <div>
          <p className="text-sm font-medium text-accent-2">Contact</p>
          <h2 className="mt-2 font-display text-4xl text-ink md:text-5xl">
            Tell us what you’re building
          </h2>
          <p className="mt-4 max-w-md text-muted">
            Partnerships, press, or a stubborn wallet question — the desk is
            open.
          </p>
        </div>
        <form
          onSubmit={onSubmit}
          className="flex flex-col gap-4 rounded-card bg-card/80 p-6 shadow-card ring-1 ring-white"
        >
          <label className="flex flex-col gap-2 text-sm font-medium text-muted">
            Name
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="h-12 rounded-panel border border-line bg-page px-4 text-ink outline-none focus:border-accent"
            />
          </label>
          <label className="flex flex-col gap-2 text-sm font-medium text-muted">
            Email
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-12 rounded-panel border border-line bg-page px-4 text-ink outline-none focus:border-accent"
            />
          </label>
          <label className="flex flex-col gap-2 text-sm font-medium text-muted">
            Message
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={4}
              className="rounded-panel border border-line bg-page px-4 py-3 text-ink outline-none focus:border-accent"
            />
          </label>
          <button
            type="submit"
            className="h-12 rounded-pill bg-cta font-semibold text-card shadow-cta"
          >
            {sent ? "Sent" : "Send message"}
          </button>
        </form>
      </div>
    </section>
  );
}
