import { cn } from "@/lib/utils";
import type { Asset } from "@/lib/store";

const assetClass: Record<Asset, string> = {
  BTC: "bg-btc",
  ETH: "bg-eth",
  USDT: "bg-usdt",
  SOL: "bg-sol",
};

export function TokenIcon({
  asset,
  className,
}: {
  asset: Asset;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-grid size-9 place-items-center rounded-full text-card shadow-sm",
        assetClass[asset],
        className,
      )}
      aria-label={asset}
    >
      {asset === "BTC" && (
        <svg viewBox="0 0 24 24" className="size-5" fill="currentColor">
          <path d="M14.4 12.6c.8-.4 1.3-1.1 1.2-2.1.2-1.6-1.2-2.3-3.2-2.5V6.3h-1.5v1.6H9.6V6.3H8.1v1.7H6.2v1.6h1.9v4.9H6.2V16h1.9v1.7h1.5V16h1.3v1.7h1.5v-1.7c2.2-.2 3.7-1 3.5-2.8-.1-.9-.7-1.5-1.5-1.8zM10 9.6h2c.9.1 1.5.4 1.5 1.1 0 .8-.6 1.2-1.7 1.2H10V9.6zm2.4 5.6H10v-2.4h2.4c1.1 0 1.8.4 1.8 1.2 0 .9-.7 1.2-1.8 1.2z" />
        </svg>
      )}
      {asset === "ETH" && (
        <svg viewBox="0 0 24 24" className="size-5" fill="currentColor">
          <path d="M12 3.2 6.8 12.1 12 15.2l5.2-3.1L12 3.2zm0 13.3-5.2-3.1L12 20.8l5.2-7.4-5.2 3.1z" />
        </svg>
      )}
      {asset === "USDT" && (
        <svg viewBox="0 0 24 24" className="size-5" fill="currentColor">
          <path d="M12.9 10.7v2.2c3.5.2 6.1 1 6.1 2 0 1.1-2.8 1.9-6.1 2.1v2.5h-1.8v-2.5c-3.4-.2-6.1-1-6.1-2.1 0-1 2.6-1.8 6.1-2V10.7H5.8V9h12.4v1.7h-5.3zM12 15.6c-3.2 0-5.2-.6-5.2-1.2s2-1.2 5.2-1.2 5.2.6 5.2 1.2-2 1.2-5.2 1.2z" />
        </svg>
      )}
      {asset === "SOL" && (
        <svg viewBox="0 0 24 24" className="size-4" fill="currentColor">
          <path d="M6.4 15.6c.2-.2.4-.2.6-.2h12.2c.4 0 .6.5.3.8l-2.4 2.5c-.2.2-.4.2-.6.2H4.3c-.4 0-.6-.5-.3-.8l2.4-2.5zm0-10.3c.2-.2.4-.2.6-.2h12.2c.4 0 .6.5.3.8l-2.4 2.4c-.2.2-.4.3-.6.3H4.3c-.4 0-.6-.5-.3-.8l2.4-2.5zm13.5 4.4c-.2-.2-.4-.3-.6-.3H7.1c-.2 0-.4.1-.6.3L4.1 12c-.3.3-.1.8.3.8h12.2c.2 0 .4-.1.6-.2l2.4-2.5c.3-.3.1-.8-.3-.8z" />
        </svg>
      )}
    </span>
  );
}

export function TokenRow({
  assets,
  className,
}: {
  assets: Asset[];
  className?: string;
}) {
  return (
    <div className={cn("flex items-center", className)}>
      {assets.map((asset, i) => (
        <TokenIcon
          key={`${asset}-${i}`}
          asset={asset}
          className={cn(
            "size-9 ring-2 ring-card",
            i > 0 && "-ml-2",
          )}
        />
      ))}
    </div>
  );
}
