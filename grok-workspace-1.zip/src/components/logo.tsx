import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

function Mark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={className}
      aria-hidden="true"
      fill="none"
    >
      <circle cx="16" cy="16" r="16" className="fill-accent" />
      <path
        d="M21.8 11.2C20.4 8.6 17.9 7 15.2 7 10.7 7 7 10.9 7 16s3.7 9 8.2 9c3.2 0 6-1.9 7.3-4.8"
        stroke="white"
        strokeWidth="2.4"
        strokeLinecap="round"
      />
      <path
        d="M18.2 16H25"
        stroke="white"
        strokeWidth="2.4"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function Logo({
  to = "/",
  className,
}: {
  to?: "/";
  className?: string;
}) {
  return (
    <Link
      to={to}
      className={cn("flex items-center gap-2 text-ink", className)}
      aria-label="NextO home"
    >
      <Mark className="size-8 shrink-0" />
      <span className="text-lg font-semibold tracking-tight">
        Next
        <span className="relative inline-block w-[0.92em] text-center">
          O
          <span className="absolute top-1/2 left-1/2 size-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-accent" />
        </span>
      </span>
    </Link>
  );
}
