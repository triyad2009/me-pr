import { useEffect, useRef, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Dashboard } from "@/components/dashboard";
import { SiteFrame } from "@/components/site-frame";
import { useWallet } from "@/lib/store";

export const Route = createFileRoute("/app")({ component: AppPage });

function AppPage() {
  const navigate = useNavigate();
  const user = useWallet((s) => s.user);
  const [ready, setReady] = useState(false);
  const hadUser = useRef(false);

  useEffect(() => {
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    if (user) {
      hadUser.current = true;
      return;
    }
    void navigate({ to: hadUser.current ? "/" : "/login" });
  }, [ready, user, navigate]);

  if (!ready || !user) {
    return (
      <SiteFrame>
        <div className="grid min-h-[60vh] place-items-center text-muted">
          Opening wallet…
        </div>
      </SiteFrame>
    );
  }

  return <Dashboard />;
}
