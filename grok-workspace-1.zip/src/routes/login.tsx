import { useEffect, useState, type FormEvent } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { SiteFrame } from "@/components/site-frame";
import { SiteHeader } from "@/components/site-header";
import { useWallet } from "@/lib/store";

export const Route = createFileRoute("/login")({ component: LoginPage });

function LoginPage() {
  const navigate = useNavigate();
  const user = useWallet((s) => s.user);
  const login = useWallet((s) => s.login);
  const enterGuest = useWallet((s) => s.enterGuest);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready && user) {
      void navigate({ to: "/app" });
    }
  }, [ready, user, navigate]);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      setError("Enter an email and password to continue.");
      return;
    }
    const name = email.split("@")[0] || "Member";
    login({
      name: name.charAt(0).toUpperCase() + name.slice(1),
      email: email.trim(),
    });
    void navigate({ to: "/app" });
  }

  function guest() {
    enterGuest();
    void navigate({ to: "/app" });
  }

  return (
    <SiteFrame>
      <SiteHeader />
      <main className="flex justify-center px-5 py-10 md:py-16">
        <form
          onSubmit={onSubmit}
          className="w-full max-w-md rounded-card bg-card/85 p-7 shadow-card ring-1 ring-white"
        >
          <p className="text-sm font-medium text-accent-2">Welcome back</p>
          <h1 className="mt-2 font-display text-4xl text-ink">Log in to NextO</h1>
          <p className="mt-3 text-sm text-muted">
            Use any email and password to open your wallet in this demo.
          </p>

          <label className="mt-6 flex flex-col gap-2 text-sm font-medium text-muted">
            Email
            <input
              type="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-12 rounded-panel border border-line bg-page px-4 text-ink outline-none focus:border-accent"
            />
          </label>
          <label className="mt-4 flex flex-col gap-2 text-sm font-medium text-muted">
            Password
            <input
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="h-12 rounded-panel border border-line bg-page px-4 text-ink outline-none focus:border-accent"
            />
          </label>
          {error ? <p className="mt-3 text-sm text-down">{error}</p> : null}

          <button
            type="submit"
            className="mt-6 h-12 w-full rounded-pill bg-cta font-semibold text-card shadow-cta"
          >
            Login
          </button>
          <button
            type="button"
            onClick={guest}
            className="mt-3 h-12 w-full rounded-pill bg-page font-semibold text-ink"
          >
            Start free trial
          </button>
          <p className="mt-5 text-center text-sm text-muted">
            Back to{" "}
            <Link to="/" className="font-medium text-ink underline">
              the homepage
            </Link>
          </p>
        </form>
      </main>
    </SiteFrame>
  );
}
