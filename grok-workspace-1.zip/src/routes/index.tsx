import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { HeroCards } from "@/components/hero-cards";
import { PageSections } from "@/components/page-sections";
import { SiteFrame } from "@/components/site-frame";
import { SiteHeader } from "@/components/site-header";
import { useWallet } from "@/lib/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const navigate = useNavigate();
  const user = useWallet((s) => s.user);
  const enterGuest = useWallet((s) => s.enterGuest);

  function startTrial() {
    if (!user) enterGuest();
    void navigate({ to: "/app" });
  }

  return (
    <SiteFrame>
      <SiteHeader />
      <main>
        <section className="hero-wash relative px-5 pb-16 pt-6 text-center md:px-10 md:pt-10 lg:px-14 lg:pt-12">
          <h1 className="font-display text-5xl leading-[1.05] tracking-tight text-ink md:text-6xl lg:text-7xl">
            The Next Era
            <br />
            of <em className="italic">Digital</em> Finance
          </h1>
          <p className="mx-auto mt-5 max-w-lg text-sm leading-relaxed text-muted md:text-base">
            Step into a platform built to transform how you interact with
            blockchain, DeFi, and the broader crypto ecosystem.
          </p>
          <button
            type="button"
            onClick={startTrial}
            className="mt-8 inline-flex h-12 items-center gap-2 rounded-pill bg-cta px-6 text-base font-semibold text-card shadow-cta transition-transform duration-150 ease-out active:scale-96"
          >
            <span className="grid size-7 place-items-center rounded-full bg-card/20">
              <Plus className="size-4" strokeWidth={2.75} />
            </span>
            Start free trial
          </button>
          <HeroCards />
        </section>
        <PageSections />
      </main>
    </SiteFrame>
  );
}
