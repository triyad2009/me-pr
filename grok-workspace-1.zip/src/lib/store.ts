import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Asset = "BTC" | "ETH" | "USDT" | "SOL";

export type TxType = "send" | "swap" | "receive";

export type Transaction = {
  id: string;
  type: TxType;
  asset: Asset;
  amount: number;
  counterparty: string;
  at: number;
};

export type SpendMonth = {
  key: "jan" | "feb" | "mar" | "apr";
  label: string;
  value: number;
};

export type User = {
  name: string;
  email: string;
};

type WalletState = {
  user: User | null;
  balance: number;
  dayChange: number;
  dayChangePct: number;
  address: string;
  spend: SpendMonth[];
  txs: Transaction[];
  login: (user: User) => void;
  enterGuest: () => void;
  logout: () => void;
  send: (amount: number, to: string, asset: Asset) => boolean;
  swap: (amount: number, from: Asset, to: Asset) => boolean;
};

const starterTxs: Transaction[] = [
  {
    id: "tx-1",
    type: "receive",
    asset: "USDT",
    amount: 840,
    counterparty: "Payroll",
    at: Date.now() - 3600_000 * 5,
  },
  {
    id: "tx-2",
    type: "swap",
    asset: "ETH",
    amount: 0.42,
    counterparty: "ETH → USDT",
    at: Date.now() - 3600_000 * 20,
  },
  {
    id: "tx-3",
    type: "send",
    asset: "BTC",
    amount: 0.012,
    counterparty: "0x8f21…aa4c",
    at: Date.now() - 3600_000 * 48,
  },
];

function uid() {
  return `tx-${Math.random().toString(36).slice(2, 9)}`;
}

export const useWallet = create<WalletState>()(
  persist(
    (set, get) => ({
      user: null,
      balance: 5237.34,
      dayChange: 55.35,
      dayChangePct: 35,
      address: "0x24534…23",
      spend: [
        { key: "jan", label: "Jan", value: 48 },
        { key: "feb", label: "Feb", value: 72 },
        { key: "mar", label: "Mar", value: 135 },
        { key: "apr", label: "Apr", value: 58 },
      ],
      txs: starterTxs,
      login: (user) => set({ user }),
      enterGuest: () =>
        set({ user: { name: "Alex Chen", email: "alex@nexto.app" } }),
      logout: () => set({ user: null }),
      send: (amount, to, asset) => {
        if (!Number.isFinite(amount) || amount <= 0) return false;
        if (amount > get().balance) return false;
        set((s) => ({
          balance: Number((s.balance - amount).toFixed(2)),
          txs: [
            {
              id: uid(),
              type: "send",
              asset,
              amount,
              counterparty: to,
              at: Date.now(),
            },
            ...s.txs,
          ],
        }));
        return true;
      },
      swap: (amount, from, to) => {
        if (!Number.isFinite(amount) || amount <= 0) return false;
        set((s) => ({
          dayChangePct: s.dayChangePct + 0.4,
          txs: [
            {
              id: uid(),
              type: "swap",
              asset: from,
              amount,
              counterparty: `${from} → ${to}`,
              at: Date.now(),
            },
            ...s.txs,
          ],
        }));
        return true;
      },
    }),
    { name: "nexto-wallet" },
  ),
);

export const markets = [
  { pair: "BTC / USDT", price: "67,420.18", change: 2.41, volume: "1.2B" },
  { pair: "ETH / USDT", price: "3,512.44", change: 1.16, volume: "842M" },
  { pair: "SOL / USDT", price: "178.92", change: 4.83, volume: "410M" },
  { pair: "TON / USDT", price: "6.41", change: -0.72, volume: "128M" },
  { pair: "LINK / USDT", price: "18.04", change: 0.95, volume: "96M" },
  { pair: "ATOM / USDT", price: "9.22", change: -1.38, volume: "54M" },
];
