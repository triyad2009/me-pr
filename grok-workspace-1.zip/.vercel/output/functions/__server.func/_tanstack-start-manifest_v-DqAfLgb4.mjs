//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DqAfLgb4.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/app",
			"/login"
		],
		preloads: [
			"/assets/index-Cr65DD4a.js",
			"/assets/rolldown-runtime-CbXtAM7H.js",
			"/assets/createLucideIcon-D8o-e5kp.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cr65DD4a.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CrlP8V7g.js",
			"/assets/site-header-DqXoW7Kk.js",
			"/assets/hero-cards-DpxG0n64.js",
			"/assets/site-frame-QedYgfuR.js"
		]
	},
	"/app": {
		filePath: "/workspace/src/routes/app.tsx",
		children: void 0,
		preloads: [
			"/assets/app-BmCzl7My.js",
			"/assets/hero-cards-DpxG0n64.js",
			"/assets/site-frame-QedYgfuR.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-B7hivCG3.js",
			"/assets/site-header-DqXoW7Kk.js",
			"/assets/site-frame-QedYgfuR.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
