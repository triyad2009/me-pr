import { i as __toESM } from "../_runtime.mjs";
import { S as useNavigate, X as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useWallet, i as markets, n as SiteFrame, r as cn, t as Logo } from "./site-frame-DFLvkIv7.mjs";
import { c as Plus, g as ArrowLeftRight, h as ArrowUpRight, u as LogOut } from "../_libs/lucide-react.mjs";
import { t as HeroCards } from "./hero-cards-CjisUBJN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-BL45vfHf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function greeting() {
	const h = (/* @__PURE__ */ new Date()).getHours();
	if (h < 12) return "Good morning";
	if (h < 18) return "Good afternoon";
	return "Good evening";
}
function timeAgo(at) {
	const mins = Math.max(1, Math.round((Date.now() - at) / 6e4));
	if (mins < 60) return `${mins}m ago`;
	const hours = Math.round(mins / 60);
	if (hours < 48) return `${hours}h ago`;
	return `${Math.round(hours / 24)}d ago`;
}
function txLabel(tx) {
	if (tx.type === "send") return `Sent ${tx.asset}`;
	if (tx.type === "swap") return `Swapped ${tx.asset}`;
	return `Received ${tx.asset}`;
}
function Dashboard() {
	const navigate = useNavigate();
	const user = useWallet((s) => s.user);
	const balance = useWallet((s) => s.balance);
	const txs = useWallet((s) => s.txs);
	const logout = useWallet((s) => s.logout);
	const [tab, setTab] = (0, import_react.useState)("activity");
	const firstName = (0, import_react.useMemo)(() => user?.name.split(" ")[0] ?? "there", [user]);
	function signOut() {
		logout();
		navigate({ to: "/" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteFrame, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex items-center justify-between gap-3 px-4 py-4 sm:px-6 md:px-8 md:py-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "hidden h-10 items-center rounded-pill bg-card px-4 text-sm font-medium text-ink shadow-sm ring-1 ring-white sm:inline-flex",
				children: user?.email
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: signOut,
				className: "inline-flex h-10 items-center gap-2 rounded-pill bg-card px-4 text-sm font-medium text-ink shadow-sm ring-1 ring-white",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), "Log out"]
			})]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "px-4 pb-16 sm:px-6 md:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-5xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-medium text-accent-2",
						children: [
							greeting(),
							", ",
							firstName
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-4xl text-ink md:text-5xl",
						children: "Your NextO wallet"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 max-w-xl text-muted",
						children: [
							balance.toLocaleString("en-US", {
								style: "currency",
								currency: "USD"
							}),
							" ",
							"ready to send, swap, or simply watch."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "#workspace",
								className: "inline-flex h-11 items-center gap-2 rounded-pill bg-cta px-5 text-sm font-semibold text-card shadow-cta",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
									className: "size-4",
									strokeWidth: 2.5
								}), "Send"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "#workspace",
								className: "inline-flex h-11 items-center gap-2 rounded-pill bg-card px-5 text-sm font-semibold text-ink shadow-sm ring-1 ring-white",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeftRight, { className: "size-4" }), "Swap"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "#markets",
								className: "inline-flex h-11 items-center gap-2 rounded-pill bg-card px-5 text-sm font-semibold text-ink shadow-sm ring-1 ring-white",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" }), "Markets"]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "workspace",
				className: "scroll-mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroCards, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "markets",
				className: "mx-auto mt-12 max-w-5xl scroll-mt-8 rounded-card bg-card/80 p-5 shadow-card ring-1 ring-white md:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2",
					children: ["activity", "markets"].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setTab(item),
						className: cn("h-10 rounded-pill px-4 text-sm font-medium capitalize", tab === item ? "bg-ink text-card" : "bg-page text-muted"),
						children: item
					}, item))
				}), tab === "activity" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 divide-y divide-line",
					children: txs.slice(0, 8).map((tx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium text-ink",
							children: txLabel(tx)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: tx.counterparty
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: cn("font-medium tabular-nums", tx.type === "receive" ? "text-accent-2" : "text-ink"),
								children: [
									tx.type === "receive" ? "+" : "-",
									tx.amount,
									" ",
									tx.asset
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-faint",
								children: timeAgo(tx.at)
							})]
						})]
					}, tx.id))
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5",
					children: markets.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b border-line py-3 last:border-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-ink",
								children: row.pair
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-ink tabular-nums",
								children: ["$", row.price]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: cn("font-medium tabular-nums", row.change >= 0 ? "text-accent-2" : "text-down"),
								children: [
									row.change >= 0 ? "+" : "",
									row.change.toFixed(2),
									"%"
								]
							})
						]
					}, row.pair))
				})]
			})
		]
	})] });
}
function AppPage() {
	const navigate = useNavigate();
	const user = useWallet((s) => s.user);
	const [ready, setReady] = (0, import_react.useState)(false);
	const hadUser = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		if (user) {
			hadUser.current = true;
			return;
		}
		navigate({ to: hadUser.current ? "/" : "/login" });
	}, [
		ready,
		user,
		navigate
	]);
	if (!ready || !user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-[60vh] place-items-center text-muted",
		children: "Opening wallet…"
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, {});
}
//#endregion
export { AppPage as component };
