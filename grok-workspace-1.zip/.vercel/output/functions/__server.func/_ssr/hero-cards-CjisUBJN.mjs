import { i as __toESM } from "../_runtime.mjs";
import { X as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useWallet, r as cn } from "./site-frame-DFLvkIv7.mjs";
import { c as Plus, f as Copy, m as ChartColumn, n as X, p as Check, r as Wallet, s as Send } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hero-cards-CjisUBJN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var assetClass = {
	BTC: "bg-btc",
	ETH: "bg-eth",
	USDT: "bg-usdt",
	SOL: "bg-sol"
};
function TokenIcon({ asset, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-grid size-9 place-items-center rounded-full text-card shadow-sm", assetClass[asset], className),
		"aria-label": asset,
		children: [
			asset === "BTC" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				viewBox: "0 0 24 24",
				className: "size-5",
				fill: "currentColor",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M14.4 12.6c.8-.4 1.3-1.1 1.2-2.1.2-1.6-1.2-2.3-3.2-2.5V6.3h-1.5v1.6H9.6V6.3H8.1v1.7H6.2v1.6h1.9v4.9H6.2V16h1.9v1.7h1.5V16h1.3v1.7h1.5v-1.7c2.2-.2 3.7-1 3.5-2.8-.1-.9-.7-1.5-1.5-1.8zM10 9.6h2c.9.1 1.5.4 1.5 1.1 0 .8-.6 1.2-1.7 1.2H10V9.6zm2.4 5.6H10v-2.4h2.4c1.1 0 1.8.4 1.8 1.2 0 .9-.7 1.2-1.8 1.2z" })
			}),
			asset === "ETH" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				viewBox: "0 0 24 24",
				className: "size-5",
				fill: "currentColor",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 3.2 6.8 12.1 12 15.2l5.2-3.1L12 3.2zm0 13.3-5.2-3.1L12 20.8l5.2-7.4-5.2 3.1z" })
			}),
			asset === "USDT" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				viewBox: "0 0 24 24",
				className: "size-5",
				fill: "currentColor",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12.9 10.7v2.2c3.5.2 6.1 1 6.1 2 0 1.1-2.8 1.9-6.1 2.1v2.5h-1.8v-2.5c-3.4-.2-6.1-1-6.1-2.1 0-1 2.6-1.8 6.1-2V10.7H5.8V9h12.4v1.7h-5.3zM12 15.6c-3.2 0-5.2-.6-5.2-1.2s2-1.2 5.2-1.2 5.2.6 5.2 1.2-2 1.2-5.2 1.2z" })
			}),
			asset === "SOL" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				viewBox: "0 0 24 24",
				className: "size-4",
				fill: "currentColor",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M6.4 15.6c.2-.2.4-.2.6-.2h12.2c.4 0 .6.5.3.8l-2.4 2.5c-.2.2-.4.2-.6.2H4.3c-.4 0-.6-.5-.3-.8l2.4-2.5zm0-10.3c.2-.2.4-.2.6-.2h12.2c.4 0 .6.5.3.8l-2.4 2.4c-.2.2-.4.3-.6.3H4.3c-.4 0-.6-.5-.3-.8l2.4-2.5zm13.5 4.4c-.2-.2-.4-.3-.6-.3H7.1c-.2 0-.4.1-.6.3L4.1 12c-.3.3-.1.8.3.8h12.2c.2 0 .4-.1.6-.2l2.4-2.5c.3-.3.1-.8-.3-.8z" })
			})
		]
	});
}
function TokenRow({ assets, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex items-center", className),
		children: assets.map((asset, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TokenIcon, {
			asset,
			className: cn("size-9 ring-2 ring-card", i > 0 && "-ml-2")
		}, `${asset}-${i}`))
	});
}
function Overlay({ open, onClose, children, labelledBy }) {
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (e) => {
			if (e.key === "Escape") onClose();
		};
		document.addEventListener("keydown", onKey);
		const prev = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		return () => {
			document.removeEventListener("keydown", onKey);
			document.body.style.overflow = prev;
		};
	}, [open, onClose]);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center p-3 sm:items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute inset-0 bg-ink/30",
			"aria-label": "Close dialog",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": labelledBy,
			className: "relative w-full max-w-md rounded-card bg-card p-6 shadow-frame",
			children
		})]
	});
}
var assets = [
	"BTC",
	"ETH",
	"USDT",
	"SOL"
];
function SendDialog({ open, onClose }) {
	const titleId = (0, import_react.useId)();
	const send = useWallet((s) => s.send);
	const [to, setTo] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("120");
	const [asset, setAsset] = (0, import_react.useState)("USDT");
	function onSubmit(e) {
		e.preventDefault();
		const value = Number(amount);
		if (!send(value, to.trim() || "0x8f21…aa4c", asset)) {
			toast.error("Not enough balance for that send.");
			return;
		}
		toast.success(`Sent ${value} ${asset}`);
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
		open,
		onClose,
		labelledBy: titleId,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-5 flex items-start justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-muted",
				children: "Quick send"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				id: titleId,
				className: "font-display text-3xl text-ink",
				children: "Send assets"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onClose,
				className: "grid size-10 place-items-center rounded-full bg-page text-ink",
				"aria-label": "Close",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex flex-col gap-4",
			onSubmit,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-2 text-sm font-medium text-muted",
					children: ["Recipient", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: to,
						onChange: (e) => setTo(e.target.value),
						placeholder: "0x24534… or @handle",
						className: "h-12 rounded-panel border border-line bg-page px-4 text-ink outline-none focus:border-accent"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-2 text-sm font-medium text-muted",
					children: ["Amount", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: amount,
						onChange: (e) => setAmount(e.target.value),
						inputMode: "decimal",
						className: "h-12 rounded-panel border border-line bg-page px-4 text-ink outline-none focus:border-accent"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2",
					children: assets.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setAsset(a),
						className: cn("flex flex-1 items-center justify-center gap-2 rounded-pill border py-2 text-xs font-semibold", asset === a ? "border-accent bg-accent/10 text-ink" : "border-line bg-page text-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TokenIcon, {
							asset: a,
							className: "size-6"
						}), a]
					}, a))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "submit",
					className: "mt-2 inline-flex h-12 items-center justify-center gap-2 rounded-pill bg-cta font-semibold text-card shadow-cta",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
						className: "size-4",
						strokeWidth: 2.5
					}), "Send now"]
				})
			]
		})]
	});
}
function SwapDialog({ open, onClose }) {
	const titleId = (0, import_react.useId)();
	const swap = useWallet((s) => s.swap);
	const [from, setFrom] = (0, import_react.useState)("BTC");
	const [to, setTo] = (0, import_react.useState)("USDT");
	const [amount, setAmount] = (0, import_react.useState)("0.02");
	function onSubmit(e) {
		e.preventDefault();
		if (from === to) {
			toast.error("Pick two different assets.");
			return;
		}
		const value = Number(amount);
		if (!swap(value, from, to)) {
			toast.error("Could not complete swap.");
			return;
		}
		toast.success(`Swapped ${value} ${from} to ${to}`);
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
		open,
		onClose,
		labelledBy: titleId,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-5 flex items-start justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-muted",
				children: "Quick swap"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				id: titleId,
				className: "font-display text-3xl text-ink",
				children: "Swap pairs"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onClose,
				className: "grid size-10 place-items-center rounded-full bg-page text-ink",
				"aria-label": "Close",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex flex-col gap-4",
			onSubmit,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-2 text-sm font-medium text-muted",
					children: ["You pay", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: amount,
						onChange: (e) => setAmount(e.target.value),
						inputMode: "decimal",
						className: "h-12 rounded-panel border border-line bg-page px-4 text-ink outline-none focus:border-accent"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex flex-col gap-2 text-sm font-medium text-muted",
						children: ["From", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: from,
							onChange: (e) => setFrom(e.target.value),
							className: "h-12 rounded-panel border border-line bg-page px-3 text-ink outline-none",
							children: assets.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: a }, a))
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex flex-col gap-2 text-sm font-medium text-muted",
						children: ["To", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: to,
							onChange: (e) => setTo(e.target.value),
							className: "h-12 rounded-panel border border-line bg-page px-3 text-ink outline-none",
							children: assets.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: a }, a))
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "100+ pairs for fast swap."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "mt-1 inline-flex h-12 items-center justify-center rounded-pill bg-cta font-semibold text-card shadow-cta",
					children: "Swap now"
				})
			]
		})]
	});
}
function formatUsd(n) {
	return n.toLocaleString("en-US", {
		style: "currency",
		currency: "USD",
		minimumFractionDigits: 2
	});
}
var monthCopy = {
	jan: "January 2023",
	feb: "February 2023",
	mar: "April 2023",
	apr: "April 2023"
};
function HeroCards() {
	const [sendOpen, setSendOpen] = (0, import_react.useState)(false);
	const [swapOpen, setSwapOpen] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [activeMonth, setActiveMonth] = (0, import_react.useState)("mar");
	const balance = useWallet((s) => s.balance);
	const dayChange = useWallet((s) => s.dayChange);
	const dayChangePct = useWallet((s) => s.dayChangePct);
	const address = useWallet((s) => s.address);
	const spend = useWallet((s) => s.spend);
	const maxSpend = Math.max(...spend.map((m) => m.value));
	function copyAddress() {
		navigator.clipboard?.writeText("0x24534a91c0b23");
		setCopied(true);
		window.setTimeout(() => setCopied(false), 1400);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto mt-8 w-full max-w-4xl lg:mt-4 lg:h-[430px]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: cn("glass-card flex min-h-40 flex-col justify-between rounded-card p-5", "transition-transform duration-250 ease-out", "lg:absolute lg:top-6 lg:left-0 lg:w-72 lg:-rotate-6", "lg:hover:z-30 lg:hover:rotate-0"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium text-muted",
							children: "Quick send"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {
							className: "size-4 text-accent",
							"aria-hidden": "true"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setSendOpen(true),
							className: "grid size-11 place-items-center rounded-full bg-accent text-card shadow-cta transition-transform duration-150 ease-out active:scale-96",
							"aria-label": "Send assets",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
								className: "size-5",
								strokeWidth: 2.5
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TokenRow, { assets: [
							"BTC",
							"ETH",
							"USDT",
							"SOL"
						] })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: cn("glass-card mt-4 flex min-h-28 items-center justify-between gap-4 rounded-card p-5", "transition-transform duration-250 ease-out", "lg:absolute lg:bottom-6 lg:left-8 lg:mt-0 lg:w-72 lg:-rotate-3", "lg:hover:z-30 lg:hover:rotate-0"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-medium text-muted",
						children: "Quick swap"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setSwapOpen(true),
						className: "mt-4 text-left",
						"aria-label": "Open swap",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TokenRow, { assets: ["BTC", "ETH"] })
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-28 text-sm leading-snug text-muted",
						children: "100+ pairs for fast swap"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: cn("glass-card relative z-20 mt-4 flex min-h-56 flex-col rounded-card p-6", "transition-transform duration-250 ease-out lg:hover:-translate-y-1", "lg:absolute lg:top-20 lg:left-1/2 lg:mt-0 lg:w-80 lg:-translate-x-1/2"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-medium text-muted",
								children: "Easy assets wallet"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, {
								className: "size-4 text-accent",
								"aria-hidden": "true"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex items-center justify-between gap-3 text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Wallet 1" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: copyAddress,
									className: "grid size-7 place-items-center rounded-full bg-page",
									"aria-label": "Copy wallet address",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "relative grid size-4 place-items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: cn("size-3.5 transition-[opacity,filter,transform] duration-250 ease-out", copied ? "scale-25 opacity-0 blur-xs" : "scale-100 opacity-100 blur-none") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: cn("absolute size-3.5 text-accent transition-[opacity,filter,transform] duration-250 ease-out", copied ? "scale-100 opacity-100 blur-none" : "scale-25 opacity-0 blur-xs") })]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs",
									children: address
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-4xl font-semibold tracking-tight text-ink tabular-nums md:text-5xl",
							children: formatUsd(balance)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-end justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted tabular-nums",
								children: formatUsd(dayChange)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold text-accent-2 tabular-nums",
								children: [
									"+",
									dayChangePct.toFixed(0),
									"%"
								]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: cn("glass-card mt-4 flex min-h-64 flex-col rounded-card p-5", "transition-transform duration-250 ease-out", "lg:absolute lg:top-4 lg:right-0 lg:mt-0 lg:w-80 lg:rotate-6", "lg:hover:z-30 lg:hover:rotate-0"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium text-muted",
							children: "You spend"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, {
							className: "size-4 text-accent",
							"aria-hidden": "true"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid min-h-16 grid-cols-4 items-end",
								children: spend.map((month) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex justify-center",
									children: month.key === activeMonth ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "rounded-xl bg-card px-2.5 py-1 text-left shadow-card",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-sm font-semibold text-ink tabular-nums",
											children: formatUsd(month.value)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-xs tracking-wide text-faint uppercase",
											children: monthCopy[month.key]
										})]
									}) : null
								}, month.key))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 flex h-28 items-end gap-3 px-2",
								children: spend.map((month) => {
									const active = month.key === activeMonth;
									const height = Math.max(28, month.value / maxSpend * 104);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setActiveMonth(month.key),
										className: "flex flex-1 flex-col items-center gap-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: cn("w-10 rounded-2xl transition-colors duration-250", active ? "bg-accent shadow-cta" : "bg-line"),
											style: { height }
										})
									}, month.key);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 grid grid-cols-4",
								children: spend.map((month) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-center text-xs text-muted",
									children: month.label
								}, month.key))
							})
						]
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SendDialog, {
			open: sendOpen,
			onClose: () => setSendOpen(false)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwapDialog, {
			open: swapOpen,
			onClose: () => setSwapOpen(false)
		})
	] });
}
//#endregion
export { HeroCards as t };
