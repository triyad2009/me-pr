import { w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-frame-DFLvkIv7.js
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var starterTxs = [
	{
		id: "tx-1",
		type: "receive",
		asset: "USDT",
		amount: 840,
		counterparty: "Payroll",
		at: Date.now() - 18e6
	},
	{
		id: "tx-2",
		type: "swap",
		asset: "ETH",
		amount: .42,
		counterparty: "ETH → USDT",
		at: Date.now() - 72e6
	},
	{
		id: "tx-3",
		type: "send",
		asset: "BTC",
		amount: .012,
		counterparty: "0x8f21…aa4c",
		at: Date.now() - 1728e5
	}
];
function uid() {
	return `tx-${Math.random().toString(36).slice(2, 9)}`;
}
var useWallet = create()(persist((set, get) => ({
	user: null,
	balance: 5237.34,
	dayChange: 55.35,
	dayChangePct: 35,
	address: "0x24534…23",
	spend: [
		{
			key: "jan",
			label: "Jan",
			value: 48
		},
		{
			key: "feb",
			label: "Feb",
			value: 72
		},
		{
			key: "mar",
			label: "Mar",
			value: 135
		},
		{
			key: "apr",
			label: "Apr",
			value: 58
		}
	],
	txs: starterTxs,
	login: (user) => set({ user }),
	enterGuest: () => set({ user: {
		name: "Alex Chen",
		email: "alex@nexto.app"
	} }),
	logout: () => set({ user: null }),
	send: (amount, to, asset) => {
		if (!Number.isFinite(amount) || amount <= 0) return false;
		if (amount > get().balance) return false;
		set((s) => ({
			balance: Number((s.balance - amount).toFixed(2)),
			txs: [{
				id: uid(),
				type: "send",
				asset,
				amount,
				counterparty: to,
				at: Date.now()
			}, ...s.txs]
		}));
		return true;
	},
	swap: (amount, from, to) => {
		if (!Number.isFinite(amount) || amount <= 0) return false;
		set((s) => ({
			dayChangePct: s.dayChangePct + .4,
			txs: [{
				id: uid(),
				type: "swap",
				asset: from,
				amount,
				counterparty: `${from} → ${to}`,
				at: Date.now()
			}, ...s.txs]
		}));
		return true;
	}
}), { name: "nexto-wallet" }));
var markets = [
	{
		pair: "BTC / USDT",
		price: "67,420.18",
		change: 2.41,
		volume: "1.2B"
	},
	{
		pair: "ETH / USDT",
		price: "3,512.44",
		change: 1.16,
		volume: "842M"
	},
	{
		pair: "SOL / USDT",
		price: "178.92",
		change: 4.83,
		volume: "410M"
	},
	{
		pair: "TON / USDT",
		price: "6.41",
		change: -.72,
		volume: "128M"
	},
	{
		pair: "LINK / USDT",
		price: "18.04",
		change: .95,
		volume: "96M"
	},
	{
		pair: "ATOM / USDT",
		price: "9.22",
		change: -1.38,
		volume: "54M"
	}
];
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className,
		"aria-hidden": "true",
		fill: "none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "16",
				r: "16",
				className: "fill-accent"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M21.8 11.2C20.4 8.6 17.9 7 15.2 7 10.7 7 7 10.9 7 16s3.7 9 8.2 9c3.2 0 6-1.9 7.3-4.8",
				stroke: "white",
				strokeWidth: "2.4",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M18.2 16H25",
				stroke: "white",
				strokeWidth: "2.4",
				strokeLinecap: "round"
			})
		]
	});
}
function Logo({ to = "/", className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: cn("flex items-center gap-2 text-ink", className),
		"aria-label": "NextO home",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-8 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-lg font-semibold tracking-tight",
			children: ["Next", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "relative inline-block w-[0.92em] text-center",
				children: ["O", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1/2 left-1/2 size-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-accent" })]
			})]
		})]
	});
}
function SiteFrame({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-canvas p-2 sm:p-3 md:p-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("page-shell relative mx-auto min-h-[calc(100dvh-1rem)] overflow-hidden rounded-3xl md:min-h-[calc(100dvh-2.5rem)] md:rounded-frame", className),
			children
		})
	});
}
//#endregion
export { useWallet as a, markets as i, SiteFrame as n, cn as r, Logo as t };
