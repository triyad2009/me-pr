import { i as __toESM } from "../_runtime.mjs";
import { S as useNavigate, X as require_react, m as useRouterState, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useWallet, r as cn, t as Logo } from "./site-frame-DFLvkIv7.mjs";
import { l as Menu, n as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-header-CJE7PiMg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var nav = [
	{
		href: "/#trade",
		label: "Trade"
	},
	{
		href: "/#product",
		label: "Product"
	},
	{
		href: "/#about",
		label: "About"
	},
	{
		href: "/#community",
		label: "Community"
	},
	{
		href: "/#contact",
		label: "Contact"
	}
];
function SiteHeader({ compact = false }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const navigate = useNavigate();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const user = useWallet((s) => s.user);
	const enterGuest = useWallet((s) => s.enterGuest);
	function startNow() {
		if (!user) enterGuest();
		navigate({ to: "/app" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "relative z-30 flex items-center justify-between gap-3 px-4 py-4 sm:px-6 md:px-8 md:py-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "hidden items-center rounded-pill bg-card/70 px-2 py-1 shadow-sm ring-1 ring-white/80 lg:flex",
				"aria-label": "Primary",
				children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: item.href,
					className: "rounded-pill px-3.5 py-2 text-sm text-muted transition-colors duration-150 hover:text-ink",
					children: item.label
				}, item.href))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					user && pathname === "/app" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/app",
						className: "hidden h-10 items-center rounded-pill bg-card px-4 text-sm font-medium text-ink shadow-sm ring-1 ring-white sm:inline-flex",
						children: user.name
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						className: "hidden h-10 items-center rounded-pill bg-card px-5 text-sm font-medium text-ink shadow-sm ring-1 ring-white/80 sm:inline-flex",
						children: "Login"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: startNow,
						className: cn("inline-flex h-10 items-center rounded-pill bg-accent px-5 text-sm font-semibold text-card shadow-sm transition-transform duration-150 ease-out active:scale-96", compact && "px-4"),
						children: "Start now"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-10 place-items-center rounded-full bg-card text-ink shadow-sm lg:hidden",
						"aria-expanded": open,
						"aria-label": open ? "Close menu" : "Open menu",
						onClick: () => setOpen((v) => !v),
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-4" })
					})
				]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute top-full right-4 left-4 z-40 rounded-card bg-card p-4 shadow-card sm:right-6 sm:left-6 lg:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "flex flex-col",
					"aria-label": "Mobile",
					children: [nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: item.href,
						onClick: () => setOpen(false),
						className: "rounded-panel px-3 py-3 text-sm font-medium text-ink",
						children: item.label
					}, item.href)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						onClick: () => setOpen(false),
						className: "rounded-panel px-3 py-3 text-sm font-medium text-ink",
						children: "Login"
					})]
				})
			}) : null
		]
	});
}
//#endregion
export { SiteHeader as t };
