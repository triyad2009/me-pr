import { i as __toESM } from "../_runtime.mjs";
import { S as useNavigate, X as require_react, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useWallet, n as SiteFrame } from "./site-frame-DFLvkIv7.mjs";
import { t as SiteHeader } from "./site-header-CJE7PiMg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-CPQmlXOt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LoginPage() {
	const navigate = useNavigate();
	const user = useWallet((s) => s.user);
	const login = useWallet((s) => s.login);
	const enterGuest = useWallet((s) => s.enterGuest);
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (ready && user) navigate({ to: "/app" });
	}, [
		ready,
		user,
		navigate
	]);
	function onSubmit(e) {
		e.preventDefault();
		if (!email.trim() || !password.trim()) {
			setError("Enter an email and password to continue.");
			return;
		}
		const name = email.split("@")[0] || "Member";
		login({
			name: name.charAt(0).toUpperCase() + name.slice(1),
			email: email.trim()
		});
		navigate({ to: "/app" });
	}
	function guest() {
		enterGuest();
		navigate({ to: "/app" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteFrame, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex justify-center px-5 py-10 md:py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "w-full max-w-md rounded-card bg-card/85 p-7 shadow-card ring-1 ring-white",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-accent-2",
					children: "Welcome back"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-4xl text-ink",
					children: "Log in to NextO"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "Use any email and password to open your wallet in this demo."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-6 flex flex-col gap-2 text-sm font-medium text-muted",
					children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "email",
						autoComplete: "email",
						value: email,
						onChange: (e) => setEmail(e.target.value),
						className: "h-12 rounded-panel border border-line bg-page px-4 text-ink outline-none focus:border-accent"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 flex flex-col gap-2 text-sm font-medium text-muted",
					children: ["Password", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "password",
						autoComplete: "current-password",
						value: password,
						onChange: (e) => setPassword(e.target.value),
						className: "h-12 rounded-panel border border-line bg-page px-4 text-ink outline-none focus:border-accent"
					})]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-down",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "mt-6 h-12 w-full rounded-pill bg-cta font-semibold text-card shadow-cta",
					children: "Login"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: guest,
					className: "mt-3 h-12 w-full rounded-pill bg-page font-semibold text-ink",
					children: "Start free trial"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-5 text-center text-sm text-muted",
					children: [
						"Back to",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "font-medium text-ink underline",
							children: "the homepage"
						})
					]
				})
			]
		})
	})] });
}
//#endregion
export { LoginPage as component };
