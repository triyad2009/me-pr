import { i as __toESM } from "../_runtime.mjs";
import { S as useNavigate, X as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useWallet, i as markets, n as SiteFrame, r as cn, t as Logo } from "./site-frame-DFLvkIv7.mjs";
import { c as Plus, d as Globe, g as ArrowLeftRight, h as ArrowUpRight, i as Users, o as ShieldCheck, r as Wallet, t as Zap } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as HeroCards } from "./hero-cards-CjisUBJN.mjs";
import { t as SiteHeader } from "./site-header-CJE7PiMg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-EwRTMV_J.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PageSections() {
	const navigate = useNavigate();
	const enterGuest = useWallet((s) => s.enterGuest);
	const user = useWallet((s) => s.user);
	function enter() {
		if (!user) enterGuest();
		navigate({ to: "/app" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "trade",
			className: "scroll-mt-24 px-5 py-20 md:px-10 lg:px-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-8 flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-accent-2",
					children: "Trade"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-display text-4xl text-ink md:text-5xl",
					children: "Markets that stay out of the way"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: enter,
					className: "inline-flex h-11 items-center gap-2 rounded-pill bg-card px-5 text-sm font-semibold text-ink shadow-sm ring-1 ring-white",
					children: ["Open terminal", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden rounded-card bg-card/80 shadow-card ring-1 ring-white",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-12 border-b border-line px-5 py-3 text-xs tracking-wide text-faint uppercase",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "col-span-4",
							children: "Pair"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "col-span-3 text-right",
							children: "Price"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "col-span-2 text-right",
							children: "24h"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "col-span-3 text-right",
							children: "Volume"
						})
					]
				}), markets.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-12 items-center border-b border-line/70 px-5 py-4 last:border-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "col-span-4 font-medium text-ink",
							children: row.pair
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "col-span-3 text-right tabular-nums text-ink",
							children: ["$", row.price]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: cn("col-span-2 text-right font-medium tabular-nums", row.change >= 0 ? "text-accent-2" : "text-down"),
							children: [
								row.change >= 0 ? "+" : "",
								row.change.toFixed(2),
								"%"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "col-span-3 text-right text-muted tabular-nums",
							children: row.volume
						})
					]
				}, row.pair))]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "product",
			className: "scroll-mt-24 px-5 py-12 md:px-10 lg:px-14",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-accent-2",
					children: "Product"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 max-w-xl font-display text-4xl text-ink md:text-5xl",
					children: "Four moves. The whole crypto stack."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
					children: [
						{
							icon: Zap,
							title: "Quick send",
							body: "Push any asset to a handle or address in two taps, with a live fee preview."
						},
						{
							icon: ArrowLeftRight,
							title: "Fast swap",
							body: "Route across 100+ pairs without leaving the wallet. Quotes refresh as you type."
						},
						{
							icon: Wallet,
							title: "Assets wallet",
							body: "One balance, many chains. Copy your address, track the day, stay in control."
						},
						{
							icon: ShieldCheck,
							title: "Spend insight",
							body: "See where value actually went — month by month — instead of a raw ledger."
						}
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-card bg-card/80 p-6 shadow-card ring-1 ring-white",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-5 text-accent-2" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-5 text-lg font-semibold text-ink",
								children: item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: item.body
							})
						]
					}, item.title))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "about",
			className: "scroll-mt-24 px-5 py-16 md:px-10 lg:grid lg:grid-cols-12 lg:gap-10 lg:px-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-accent-2",
						children: "About"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-4xl text-ink md:text-5xl",
						children: "Built for how finance actually feels now"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-lg text-base leading-relaxed text-muted",
						children: "NextO is a platform for people who want blockchain, DeFi, and the broader crypto ecosystem without the noise. We started with send, swap, and a clear wallet — then added spend tracking so the numbers mean something."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
				className: "mt-10 grid grid-cols-3 gap-4 lg:col-span-6 lg:mt-10",
				children: [
					["2.4M", "Wallets opened"],
					["100+", "Swap pairs"],
					["0.04s", "Quote time"]
				].map(([stat, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-card bg-card/80 p-5 text-center shadow-card ring-1 ring-white",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "font-display text-3xl text-ink md:text-4xl",
						children: stat
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-2 text-xs text-muted md:text-sm",
						children: label
					})]
				}, label))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "community",
			className: "scroll-mt-24 px-5 py-12 md:px-10 lg:px-14",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-card bg-card/80 px-6 py-10 shadow-card ring-1 ring-white md:px-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col justify-between gap-8 md:flex-row md:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "inline-flex items-center gap-2 text-sm font-medium text-accent-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" }), "Community"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 max-w-md font-display text-4xl text-ink",
							children: "Builders, traders, and the quietly curious"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-md text-muted",
							children: "Weekly market notes, office hours, and a forum that still reads like people — not bots."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#contact",
							className: "inline-flex h-12 items-center justify-center gap-2 rounded-pill bg-cta px-6 font-semibold text-card shadow-cta",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-4" }), "Join the room"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-center text-sm text-muted",
							children: "86k members across 40 countries"
						})]
					})]
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactSection, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
			className: "mt-8 flex flex-col gap-6 border-t border-white/60 px-5 py-8 md:flex-row md:items-center md:justify-between md:px-10 lg:px-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" NextO. Digital finance, without the fog."
				]
			})]
		})
	] });
}
function ContactSection() {
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	const [sent, setSent] = (0, import_react.useState)(false);
	function onSubmit(e) {
		e.preventDefault();
		if (!name.trim() || !email.trim() || !message.trim()) {
			toast.error("Please fill in every field.");
			return;
		}
		setSent(true);
		toast.success("Message received. We’ll write back shortly.");
		setName("");
		setEmail("");
		setMessage("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "contact",
		className: "scroll-mt-24 px-5 py-16 md:px-10 lg:px-14",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-10 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-accent-2",
					children: "Contact"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-display text-4xl text-ink md:text-5xl",
					children: "Tell us what you’re building"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-md text-muted",
					children: "Partnerships, press, or a stubborn wallet question — the desk is open."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "flex flex-col gap-4 rounded-card bg-card/80 p-6 shadow-card ring-1 ring-white",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex flex-col gap-2 text-sm font-medium text-muted",
						children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: name,
							onChange: (e) => setName(e.target.value),
							className: "h-12 rounded-panel border border-line bg-page px-4 text-ink outline-none focus:border-accent"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex flex-col gap-2 text-sm font-medium text-muted",
						children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "email",
							value: email,
							onChange: (e) => setEmail(e.target.value),
							className: "h-12 rounded-panel border border-line bg-page px-4 text-ink outline-none focus:border-accent"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex flex-col gap-2 text-sm font-medium text-muted",
						children: ["Message", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: message,
							onChange: (e) => setMessage(e.target.value),
							rows: 4,
							className: "rounded-panel border border-line bg-page px-4 py-3 text-ink outline-none focus:border-accent"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "h-12 rounded-pill bg-cta font-semibold text-card shadow-cta",
						children: sent ? "Sent" : "Send message"
					})
				]
			})]
		})
	});
}
function Home() {
	const navigate = useNavigate();
	const user = useWallet((s) => s.user);
	const enterGuest = useWallet((s) => s.enterGuest);
	function startTrial() {
		if (!user) enterGuest();
		navigate({ to: "/app" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteFrame, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "hero-wash relative px-5 pb-16 pt-6 text-center md:px-10 md:pt-10 lg:px-14 lg:pt-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "font-display text-5xl leading-[1.05] tracking-tight text-ink md:text-6xl lg:text-7xl",
				children: [
					"The Next Era",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					"of ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
						className: "italic",
						children: "Digital"
					}),
					" Finance"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-5 max-w-lg text-sm leading-relaxed text-muted md:text-base",
				children: "Step into a platform built to transform how you interact with blockchain, DeFi, and the broader crypto ecosystem."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: startTrial,
				className: "mt-8 inline-flex h-12 items-center gap-2 rounded-pill bg-cta px-6 text-base font-semibold text-card shadow-cta transition-transform duration-150 ease-out active:scale-96",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-7 place-items-center rounded-full bg-card/20",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
						className: "size-4",
						strokeWidth: 2.75
					})
				}), "Start free trial"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroCards, {})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSections, {})] })] });
}
//#endregion
export { Home as component };
